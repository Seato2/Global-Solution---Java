package controller;

import controller.DTO.ConsultasDTO;
import entities.Consultas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import repository.ConsultasRepository;
import service.ConsultasService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/consultas")
public class ConsultasController {
    private final ConsultasService consultasService;

    public ConsultasController(@Autowired ConsultasService consultasService) {
            this.consultasService = consultasService;
    }

    @GetMapping
    public ResponseEntity<List<ConsultasDTO>> getAllConsultas(@RequestParam int pageSize,
                                                              @RequestParam int pageNumber) {
        return ResponseEntity.ok().body(consultasService.findAll(PageRequest.of(pageNumber, pageSize)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ConsultasDTO> getConsultasById(@PathVariable Long id) {
        Optional<ConsultasDTO> consultasDTO = consultasService.findById(id);

        if (consultasDTO.isPresent()) {
            return ResponseEntity.ok().body(consultasDTO.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();

        }
    }

    @PostMapping
    public ResponseEntity<ConsultasDTO> deleteConsultas(){
        return ResponseEntity.ok().body(new ConsultasDTO());
    }

    @DeleteMapping
    public ResponseEntity<ConsultasDTO> deleteProduct() {
        return ResponseEntity.ok().body(new ConsultasDTO());
    }

    @PutMapping
    public ResponseEntity<ConsultasDTO> updateConsultas(){
        return ResponseEntity.ok().body(new ConsultasDTO());
    }
}
