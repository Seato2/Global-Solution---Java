package controller.DTO;
import entities.Consultas;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ConsultasDTO {

    public ConsultasDTO(){

    }
    public ConsultasDTO(Consultas consultas){
        this.Id = consultas.getId();
        this.DataHoraConsulta = consultas.getDataHoraConsulta();
        this.DescricaoSintomas = consultas.getDescricaoSintomas();
        this.Status = consultas.getStatus();
        this.Prioridade = consultas.getPrioridade();

    }

    private Long Id;

    @NotNull(message = "Data e Hora da consulta nao pode ser nulo")
    @NotBlank(message = "Data e Hora da consulta nao pode ser vazio")
    private LocalDateTime DataHoraConsulta;

    @NotNull(message = "Descricao dos Sintomas  nao pode ser nulo")
    @NotBlank(message = "Descricao dos Sintomas nao pode ser vazio")
    private String DescricaoSintomas;

    @NotNull(message = "Status nao pode ser nulo")
    @NotBlank(message = "Status nao pode ser vazio")
    private String Status;

    @NotNull(message = "Prioridade nao pode ser nulo")
    @NotBlank(message = "Prioridade nao pode ser vazio")
    private int Prioridade;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public LocalDateTime getDataHoraConsulta() {
        return DataHoraConsulta;
    }

    public void setDataHoraConsulta(LocalDateTime dataHoraConsulta) {
        DataHoraConsulta = dataHoraConsulta;
    }

    public String getDescricaoSintomas() {
        return DescricaoSintomas;
    }

    public void setDescricaoSintomas(String descricaoSintomas) {
        DescricaoSintomas = descricaoSintomas;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public int getPrioridade() {
        return Prioridade;
    }

    public void setPrioridade(int prioridade) {
        Prioridade = prioridade;
    }
}
