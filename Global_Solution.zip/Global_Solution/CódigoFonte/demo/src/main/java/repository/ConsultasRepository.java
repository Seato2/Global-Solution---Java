package repository;

import entities.Consultas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsultasRepository extends JpaRepository<Consultas,Long> {

}
