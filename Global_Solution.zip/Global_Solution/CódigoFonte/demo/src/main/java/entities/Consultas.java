package entities;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Consultas")
public class Consultas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    private LocalDateTime DataHoraConsulta;
    private String DescricaoSintomas;
    private String Status;
    private int Prioridade;

    @OneToMany(mappedBy = "consultas")
    private List<HistoricoConsultas> historicoConsultas;

    @OneToMany(mappedBy = "consultas")
    private List<Diagnosticos> diagnosticos;

    @OneToMany(mappedBy = "consultas")
    private List<Mensagens> mensagens;

    @OneToMany(mappedBy = "consultas")
    private List<Sintomas> sintomas;

    @ManyToOne
    @JoinColumn(name = "ID_Paciente")
    private Pacientes pacientes;

}
