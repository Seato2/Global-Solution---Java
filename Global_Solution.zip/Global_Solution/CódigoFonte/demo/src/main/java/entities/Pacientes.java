package entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Pacientes")
public class Pacientes {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    private String nome;
    private String CPF;
    private LocalDateTime DataNascimento;
    private String Sexo;
    private String Endereco;
    private String Contato;

    @OneToMany(mappedBy = "pacientes")
    private List<Consultas> consultasX;

}
